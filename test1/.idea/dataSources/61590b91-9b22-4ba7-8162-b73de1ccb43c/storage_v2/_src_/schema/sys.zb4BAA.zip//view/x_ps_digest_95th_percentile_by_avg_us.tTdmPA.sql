CREATE VIEW `x$ps_digest_95th_percentile_by_avg_us` AS
  SELECT
    `s2`.`avg_us`                                                                                               AS `avg_us`,
    ifnull((sum(`s1`.`cnt`) / nullif((SELECT count(0)
                                      FROM `performance_schema`.`events_statements_summary_by_digest`), 0)),
           0)                                                                                                   AS `percentile`
  FROM (`sys`.`x$ps_digest_avg_latency_distribution` `s1`
    JOIN `sys`.`x$ps_digest_avg_latency_distribution` `s2` ON ((`s1`.`avg_us` <= `s2`.`avg_us`)))
  GROUP BY `s2`.`avg_us`
  HAVING (ifnull((sum(`s1`.`cnt`) / nullif((SELECT count(0)
                                            FROM `performance_schema`.`events_statements_summary_by_digest`), 0)), 0) >
          0.95)
  ORDER BY `percentile`
  LIMIT 1;

